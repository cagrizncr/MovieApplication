﻿using CinemaOffer.Entity.Concrete;
using System;

namespace CinemaOffer.Entity
{
    public class UserEntity:BaseEntity
    {
        public decimal? recordId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }
}
