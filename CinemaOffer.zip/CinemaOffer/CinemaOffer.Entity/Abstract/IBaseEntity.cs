﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CinemaOffer.Entity.Abstract
{
    public interface IBaseEntity
    {
        DateTime CreatedAt { get; set; }
        DateTime ModifiedAt { get; set; }
        bool IsDeleted{ get; set; }
    }
}
