﻿using CinemaOffer.Entity.Abstract;
using System;

namespace CinemaOffer.Entity.Concrete
{
    public class BaseEntity : IBaseEntity
    {
        public DateTime CreatedAt { get; set ; }
        public DateTime ModifiedAt { get ; set ; }
        public bool IsDeleted { get ; set ; }
    }
}
