﻿using CinemaOffer.Entity.Concrete;

namespace CinemaOffer.Entity
{
    public class MovieEntity:BaseEntity
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Overview { get; set; }
        public string Note { get; set; }
        public double? Rating{ get; set; }
    }
}
