﻿using Microsoft.IdentityModel.Tokens;

namespace CinemaOffer.Core.Security.Encryption
{
    public class SigningCredentialsHelper
    {
        public static SigningCredentials CreateSigningCredentials(SecurityKey securitKey)
        {
            return new SigningCredentials(securitKey, SecurityAlgorithms.HmacSha256);
        }
    }
}
