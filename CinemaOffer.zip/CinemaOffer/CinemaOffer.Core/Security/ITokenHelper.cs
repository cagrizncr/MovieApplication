﻿using CinemaOffer.Entity;
using System.Collections.Generic;
using System.Security.Claims;

namespace CinemaOffer.Core.Security
{
    public interface ITokenHelper
    {
        AccessToken CreateToken(UserEntity user);
        IEnumerable<Claim> SetClaims(UserEntity user);
    }
}
