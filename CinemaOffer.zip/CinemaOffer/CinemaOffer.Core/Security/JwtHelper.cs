﻿using CinemaOffer.Core.Security.Encryption;
using CinemaOffer.Entity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace CinemaOffer.Core.Security
{
    public class JwtHelper : ITokenHelper
    {
        private IConfiguration _configuration;
        private TokenOptions _tokenOptions;
        public DateTime _accessTokenExpiration { get; set; }
        public JwtHelper(IConfiguration configuration) 
        {
            _configuration = configuration;
            //_tokenOptions = configuration.GetSection("TokenOptions").Get<TokenOptions>(); 
            _accessTokenExpiration = DateTime.Now.AddMinutes(_tokenOptions.AccessTokenExpiration); 
        }

        public AccessToken CreateToken(UserEntity user)
        {
            var securityKey = SecurityKeyHelper.CreateSecurityKey(_tokenOptions.SecurityKey);
            var signingCredentials = SigningCredentialsHelper.CreateSigningCredentials(securityKey);
            var jwt = CreateJwtSecurityToken(_tokenOptions, user, signingCredentials);
            var jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
            var token = jwtSecurityTokenHandler.WriteToken(jwt);
            return new AccessToken() { Token = token, Expiration = _accessTokenExpiration };
        }

        public IEnumerable<Claim> SetClaims(UserEntity user)
        {
            var claims = new List<Claim>();
            claims.Add(new Claim("UserId", user.recordId.ToString()));
            return claims;
        }
        private JwtSecurityToken CreateJwtSecurityToken(TokenOptions tokenOptions, UserEntity user, SigningCredentials signingCredentials)
        {
            return new JwtSecurityToken(
                issuer: tokenOptions.Issuer,
                audience: tokenOptions.Audience,
                expires: _accessTokenExpiration,
                notBefore: DateTime.Now,
                claims: SetClaims(user),
                signingCredentials: signingCredentials);
        }
    }
}
