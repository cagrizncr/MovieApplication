﻿using CinemaOffer.Core.Enums;
using FluentValidation.Results;
using System;
using System.Collections.Generic;

namespace CinemaOffer.Core.Utilities.Results
{

    public partial class Result<T>
    {
        public bool IsSuccess
        {
            get
            {
                return (this.Errors.Count == 0);
            }
        }
        private T _data;

        public T Data
        {
            get
            {
                if (this.Errors.Count > 0)
                {
                    return default(T);
                }
                return _data;
            }
            set { _data = value; }
        }

        //public T Data
        //{
        //    get
        //    {
        //        if (this.Errors.Count > 0)
        //        {
        //            return default(T);
        //        }
        //        return Data;
        //    }
        //    set { }
        //}
        public IList<Error> Errors { get; set; }

        private string _Message;
        public string Message
        {
            get
            {
                if (this.Errors.Count > 0)
                {
                    return "Lütfen hata listesini kontrol ediniz"; //TODO //Burası Ml ye baglanacak sonradan
                }
                
                return _Message;
            }
            set { _Message = value; }
        }
        public void AddError(int code, string Message)
        {
            this.Errors.Add(new Error { Code = code, Message = Message });
        }
        public void AddError(int code, string Message, string Detail)
        {
            this.Errors.Add(new Error { Code = code, Message = Message, Detail = Detail });
        }
        /// <summary>
        /// Validation Listesinden Dönen Hataları Ekler
        /// </summary>
        /// <param name="validationResults"></param>
        public void AddError(ValidationResult validationResults)
        {
            foreach (var item in validationResults.Errors)
            {
                this.Errors.Add(new Error { Code = int.TryParse(item.ErrorCode, out _) == true ? Convert.ToInt32(item.ErrorMessage) : (int?)null, Message = item.ErrorMessage });
            }
        }
        public void ErrorAddRange(IList<Error> errors)
        {
            foreach (var errorItem in errors)
            {
                this.Errors.Add(errorItem);
            }
        }
    }
}
