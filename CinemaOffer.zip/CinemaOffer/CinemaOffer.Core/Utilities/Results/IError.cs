﻿
namespace CinemaOffer.Core.Utilities.Results
{
    public interface IError
    {
        public int? Code { get; set; }
        public string Message { get; set; }
    }
}
