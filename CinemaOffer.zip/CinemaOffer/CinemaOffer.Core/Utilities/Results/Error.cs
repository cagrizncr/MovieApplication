﻿
namespace CinemaOffer.Core.Utilities.Results
{
    public class Error : IError
    {
        public int? Code { get; set; }
        public string Message { get; set; }
        public string Detail { get; set; }
    }
}
