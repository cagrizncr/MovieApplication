﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CinemaOffer.Core.Enums
{

    public enum NotificationCodeEnums
    {
        SuccessMessage = 1,
        ErrorMessage = 2,
        DbError = 3,
        NotEmpty = 4,
        DocumentamountIsWrong = 5,
        ParameterCannotBeNullOrEmpty = 6,
        SalesQuantityNotZero = 7,
        Error_Customer_NotFound = 8,
        Error_WareHouse_NotFound = 9,
        Error_PaymentType_NotFound = 10,
        Error_RecordId_NotFound = 11,
        Error_Currency_NotFound = 12,
        Error_Is_Not_Valid = 13,
        Error_Items_NotFound = 14,
        Error_SalesUnit_NotFound = 15,
        Error_DiscountClass_NotFound = 16,
        Error_DiscountCode_NotFound = 17,
        Error_DiscountReason_NotFound = 18,
        Error_StatusCode_NotFound = 19,
        Error_Loyalty_NotFound = 20,
        Error_UserName_NotFound = 21,
        Error_User_NotFound = 22,
        Error_Recv_Location_NotFound = 23,
        Error_Location_NotValidated = 24,
        Error_Cust_PriceList_NotFound = 25,
    }
}
