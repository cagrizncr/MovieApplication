﻿using CinemaOffer.Core.Abstract;
using CinemaOffer.Core.Security;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CinemaOffer.Core.Concrete
{
    public class CoreModule : ICoreModule
    {
        public void Load(IServiceCollection services)
        {
            services.AddSingleton<ITokenHelper, JwtHelper>(); 
        }
    }
}
