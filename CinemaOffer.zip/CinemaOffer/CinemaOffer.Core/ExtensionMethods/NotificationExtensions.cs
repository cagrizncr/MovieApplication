﻿using CinemaOffer.Core.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Text;

namespace CinemaOffer.Core.ExtensionMethods
{
    public static class NotificationCodeExtensions
    {
        public static string Message(this NotificationCodeEnums NotificationCode)
        {
            FieldInfo fi = NotificationCode.GetType().GetField(NotificationCode.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null &&
                attributes.Length > 0)
                return attributes[0].Description;
            else
                return NotificationCode.ToString();
        }
    }
}
