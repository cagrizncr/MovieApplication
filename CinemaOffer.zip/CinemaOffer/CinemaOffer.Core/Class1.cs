﻿using System;

namespace CinemaOffer.Core
{
    public class Class1
    {
    }
}
