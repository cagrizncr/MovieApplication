﻿using CinemaOffer.BusinessLayer.Abstract;
using CinemaOffer.DAL;
using CinemaOffer.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace CinemaOffer.BusinessLayer.Concrete
{
    public class MovieService : IMovieService
    {
        private DbContext _context;
        public MovieService()
        {
            if (_context == null)
                _context = new DbContext();
        }
        public int Add(MovieEntity movie)
        {
            var oldMovie = _context.Movies.FirstOrDefault(x => x.Id == movie.Id);
            if (oldMovie == null)
                _context.Movies.Add(movie);
            return movie.Id;
        }

        public MovieEntity Get(Func<MovieEntity, bool> where)
        {
            if (where != null)
                return _context.Movies.FirstOrDefault(where);
            else return null;
        }
     

        public List<MovieEntity> GetList(Func<MovieEntity, bool> where)
        {
            if (where != null)
                return _context.Movies.Where(where).ToList();
            else return null;
        }

        public bool Remove(MovieEntity movie)
        {
            _context.Movies.Remove(movie);
            return true;
        }

        public bool Update(MovieEntity movie)
        {
            var oldMovie = _context.Movies.FirstOrDefault(x => x.Id == movie.Id);
            if (oldMovie != null)
            {
                _context.Movies.Remove(oldMovie);
                _context.Movies.Add(movie);
                return true;
            }
            return false;
        }
    }
}
