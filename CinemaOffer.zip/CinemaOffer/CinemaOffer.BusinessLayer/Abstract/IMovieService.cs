﻿using CinemaOffer.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace CinemaOffer.BusinessLayer.Abstract
{
    public interface IMovieService
    {
        int Add(MovieEntity movie);
        bool Update(MovieEntity movie);
        MovieEntity Get(Func<MovieEntity, bool> where);
        List<MovieEntity> GetList(Func<MovieEntity, bool> where);

        bool Remove(MovieEntity movie);
    }
}
