﻿using CinemaOffer.Core.Concrete;
using CinemaOffer.Core.Utilities.Results;
using CinemaOffer.Entity;

namespace CinemaOffer.BusinessLayer.Abstract
{
    public interface IUserService
    {
        Result<UserEntity> GetByUsername(string userName);
        Result<UserEntity> GetByUsernamePassword(BaseUserModel userModel);
    }
}
