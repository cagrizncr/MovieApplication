﻿using CinemaOffer.Entity;
using System;
using System.Collections.Generic;

namespace CinemaOffer.DAL
{
    public class DbContext
    {
        public List<MovieEntity> Movies{ get; set; }
        public DbContext()
        {
            Movies = new List<MovieEntity>();
        }
    }
}
