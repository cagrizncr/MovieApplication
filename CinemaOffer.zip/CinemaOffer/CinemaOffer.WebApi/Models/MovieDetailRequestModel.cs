﻿
namespace CinemaOffer.WebApi.Models
{
    public class MovieDetailRequestModel :BaseModel
    {
    }
}
