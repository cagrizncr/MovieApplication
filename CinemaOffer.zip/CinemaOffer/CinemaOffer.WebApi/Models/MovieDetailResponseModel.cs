﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaOffer.WebApi.Models
{
    public class MovieDetailResponseModel:BaseModel
    {
        #region MovieDB Fields
        public string Title { get; set; }
        public string Overview { get; set; }
        public string Poster { get; set; }

        public double? VoteAverage { get; set; }

        public DateTime ReleaseDate { get; set; }
        #endregion

        #region Custom Fields
        public string Note { get; set; }
        public double? Rating { get; set; }

        #endregion
    }
}
