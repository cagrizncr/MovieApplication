﻿
namespace CinemaOffer.WebApi.Models
{
    public class MovieRequestModel:BaseModel
    {
        public int? PageSize { get; set; }

        public int? Page{ get; set; }
    }
}
