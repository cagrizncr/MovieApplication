﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaOffer.WebApi.Models
{
    public class BaseModel
    {
        public int Id { get; set; }
    }
}
