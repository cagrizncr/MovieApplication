﻿

namespace CinemaOffer.WebApi.Models
{
    public class MovieUpdateRequestModel:BaseModel
    {
        public string Note { get; set; }
        public double? Rating { get; set; }
    }
}
