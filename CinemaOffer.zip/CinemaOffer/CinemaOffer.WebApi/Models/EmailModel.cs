﻿using CinemaOffer.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaOffer.WebApi.Models
{
    public class EmailModel
    {

        public string toEmail { get; set; }
        public string subject { get; set; }
        public string body { get; set; } 
        public string mailAddressFrom { get; set; }

    }
}
