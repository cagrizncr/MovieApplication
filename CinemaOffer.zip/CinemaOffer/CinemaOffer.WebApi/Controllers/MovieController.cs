﻿using CinemaOffer.WebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Linq;
using CinemaOffer.BusinessLayer.Concrete;
using CinemaOffer.BusinessLayer.Abstract;
using CinemaOffer.Core.Utilities.Results;
using System;
using CinemaOffer.WebApi.EmailHelper;
using Microsoft.Extensions.Configuration;
using System.Configuration;
using CinemaOffer.WebApi.Html;

namespace CinemaOffer.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : Controller
    {
        private IMovieService _movieService;
        private readonly IConfiguration _configuration;
        private const string baseUrl = "https://api.themoviedb.org/3/";
        private const string apiKey = "58cdb7da816f666f429388f9a1f0c557";

        public MovieController(IMovieService movieService, IConfiguration configuration)
        {
            _movieService = movieService;
            _configuration = configuration; 
        }

        [HttpGet("GetMovies")]
        public async Task<ActionResult<MovieListResponseModel>> GetMovies([FromQuery] MovieRequestModel model)
        {
            using (HttpClient client = new HttpClient())
            {
                var responseMessage = await client.GetAsync("https://api.themoviedb.org/3/movie/popular?api_key=58cdb7da816f666f429388f9a1f0c557&language=en-US&page=1");

                var content = responseMessage.Content;
                var data = JsonConvert.DeserializeObject<MovieListResponseModel>(await content.ReadAsStringAsync());
                if (data != null)
                {
                    if (model.PageSize.HasValue)
                        data.Results = data.Results.Take(model.PageSize.Value).ToList();

                    foreach (var movie in data.Results)
                    {
                        _movieService.Add(new Entity.MovieEntity { Id=movie.Id,Title=movie.Title,Overview=movie.Overview,CreatedAt=DateTime.Now});
                    }
                }

                return data;
            }
        }


        [HttpPost("UpdateMovies")]
        public ActionResult<ApiResult> UpdateMovies([FromQuery] MovieUpdateRequestModel model)
        {
            var movie = _movieService.Get(x => x.Id == model.Id);
            if (movie == null)
                return new ApiResult { Success = false, Message = "Film Bulunamadı" };

            if (model.Rating.HasValue)
                movie.Rating = model.Rating.Value;
            movie.Note = model.Note;

            _movieService.Update(movie);
            return new ApiResult { Success = true, Message = "Film Güncellendi." };
        }


        [HttpGet("FindMovie")]
        public async Task<ActionResult<MovieDetailResponseModel>> FindMovie([FromQuery] MovieDetailRequestModel model)
        {
            using (HttpClient client = new HttpClient())
            {
                var url = string.Format("{0}movie/{1}?api_key={2}&language=en-US", baseUrl,model.Id,apiKey);
                var responseMessage = await client.GetAsync(url);

                var content = responseMessage.Content;
                var stringg = await content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<Movie>(await content.ReadAsStringAsync());

                var movieDetailModel = new MovieDetailResponseModel();
                if (data!=null)
                {
                    movieDetailModel.Id = model.Id;

                    var movieFormList = data;
                    if (movieFormList!=null)
                    {
                        movieDetailModel.Title = movieFormList.Title;
                        movieDetailModel.Overview = movieFormList.Overview;
                        movieDetailModel.Poster = movieFormList.Poster;
                        movieDetailModel.VoteAverage = movieFormList.VoteAverage;
                        movieDetailModel.ReleaseDate = movieFormList.ReleaseDate;
                    }
                }
                var movie = _movieService.Get(x=>x.Id==model.Id);
                if (movie!=null)
                {
                    movieDetailModel.Note = movie.Note;
                    movieDetailModel.Rating = movie.Rating;
                }

                return movieDetailModel;
            }
        }

        [HttpPost("SuggestMovieEmail")] 
        public ActionResult<ApiResult> SuggestMovieEmail([FromQuery] EmailRequestModel model)  
        {
            var movie = _movieService.Get(x => x.Id == model.Id);
            if (movie == null)
                return new ApiResult { Success = false, Message = "Film Bulunamadı" };
           
            else 
            {
                //HtmlHelper html = new HtmlHelper();
                //string htmlString;
                //htmlString = html.LoadSuccesHtmlData();

                var email = new EmailModel()
                {
                mailAddressFrom = _configuration["EmailHelper:mailAddressFrom"],
                toEmail = _configuration["EmailHelper:toEmail"],
                body = movie.Title,
                subject = "Önerilen Film"
                };

                MailHelper mail = new MailHelper(_configuration); 
                mail.SendEMail(email);
                
              
            } 

            return new ApiResult { Success = true, Message = "Film Önerildi." };  

        }
    }
}
