﻿using CinemaOffer.BusinessLayer.Abstract;
using CinemaOffer.Core.Concrete;
using CinemaOffer.Core.Enums;
using CinemaOffer.Core.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaOffer.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : BaseApiController
    {
        private IUserService _userService;
        private ITokenHelper _tokenHelper;

        public AuthController(IUserService userService, ITokenHelper tokenHelper)
        {
            _userService = userService;
            _tokenHelper = tokenHelper;
        }
        [AllowAnonymous]
        [HttpPost("Token")]
        public IActionResult Token([FromBody] BaseUserModel model)
        {
            var loginInfo = _userService.GetByUsernamePassword(model);
            if (!loginInfo.IsSuccess)
                return Unauthorized(NotificationCodeEnums.Error_User_NotFound);
            var token = _tokenHelper.CreateToken(loginInfo.Data);
            return Ok(token);
        }
    }
}
