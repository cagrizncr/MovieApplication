﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaOffer.WebApi.Html
{
    public class HtmlHelper : IHtmlHelper
    {
        public string LoadSuccesHtmlData()
        {
            string successHtmlTemplate;

            using (StreamReader reader = new StreamReader(ConfigurationManager.AppSettings["HtmlHelper:SuccesTemplateHtml"]))
            {
                successHtmlTemplate = reader.ReadToEnd(); 
            }
            return successHtmlTemplate; 
        }
    }
}
