﻿using CinemaOffer.BusinessLayer.Abstract;
using CinemaOffer.BusinessLayer.Concrete;
using CinemaOffer.DAL;
using CinemaOffer.WebApi.EmailHelper;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace CinemaOffer.WebApi.SetDI
{
    public static class SetDI
    {
        public static void DependencyServices(IServiceCollection services)
        {
            services.AddSingleton<DbContext>();
            //Scoped daha doğru ama her istekte newlenmesi gerekiyor.
            services.AddSingleton<IMovieService, MovieService>();
            services.TryAddTransient<IMailHelper, MailHelper>();  
        }
    }
}
