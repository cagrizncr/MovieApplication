﻿using CinemaOffer.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaOffer.WebApi.EmailHelper
{
   public interface IMailHelper
    {
        bool SendEMail(EmailModel email); 
    }
}
