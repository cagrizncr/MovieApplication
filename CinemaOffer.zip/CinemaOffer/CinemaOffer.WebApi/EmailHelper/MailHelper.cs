﻿using CinemaOffer.Entity;
using CinemaOffer.WebApi.Models;
using FluentAssertions.Common;
using log4net;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace CinemaOffer.WebApi.EmailHelper
{
    public class MailHelper : IMailHelper
    {
        private readonly IConfiguration _configuration;
        public MailHelper(IConfiguration configuration) 
        {
            _configuration = configuration;
        }

        public bool SendEMail(EmailModel email) 
        {

            var oSendLogger = LogManager.GetLogger("MailSendLogger"); 
            try
            {
                SmtpClient smtpClient = new SmtpClient();
                var basicCredential = new NetworkCredential(_configuration["Network:NetworkCredentialMailAdress"], _configuration["Network:NetworkCredentialPassword"]);
                using (MailMessage message = new MailMessage())
                {
                    smtpClient.Host = _configuration["Network:smtpClientHost"];
                    smtpClient.Port = Convert.ToInt32(_configuration["Network:smtpClientPort"]); 
                    smtpClient.EnableSsl = true;
                    smtpClient.UseDefaultCredentials = false;  
                    smtpClient.Credentials = basicCredential;
                    smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network; 
                    message.Subject = email.subject; 
                    // Set IsBodyHtml to true means you can send HTML email.
                    message.IsBodyHtml = true;
                    message.Body = email.body;
                    string[] mailAddresses = email.toEmail.Split(';');
                    foreach (string mailAddress in mailAddresses)
                        if (!string.IsNullOrEmpty(mailAddress.Trim()))
                            message.To.Add(mailAddress);

                    if (String.IsNullOrEmpty(email.mailAddressFrom) == false)
                    {
                        mailAddresses = email.mailAddressFrom.Split(';');
                        foreach (string mailAddress in mailAddresses)
                            if (!string.IsNullOrEmpty(mailAddress.Trim()))
                                message.From = new MailAddress(email.mailAddressFrom); 
                    }
                    smtpClient.Send(message);
                    return true;
                }
            }
            catch (SmtpException ex)
            {
                oSendLogger.ErrorFormat("Error Date:{0} Subject:{1} MailAddress{2} Message{3}",
                                                        DateTime.Now, email.subject,
                                                        email.toEmail, ex.Message); 

                return false;
            }
        }
    }
}
